<?php

//checking the id
if (!isset($_GET['id'])) {
    header("Location: index.php");
} else {
    $id = $_GET['id'];
}

include "libs/load.php";
include "libs/cookie/cookies.php";
// cookie::checkcookie();
load_template("head");
load_template("nav");
load_template("update_body");
load_template("footer2");
