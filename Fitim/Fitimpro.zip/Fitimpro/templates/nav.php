<nav class="navbar navbar-expand-md navbar-dark  mb-2" style="margin-top:-25px;">
	<div class="container-fluid">
		<!-- <a class="navbar-brand" href="#">Home</a> -->
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
			aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarCollapse">
			<ul class="navbar-nav me-auto mb-2 mb-md-0">
				<li class="nav-item">
					<a class="nav-link bg-primary text-white" style="font-size:20px;border-radius:5px;"
						aria-current="page" href="index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link bg-primary text-white"
						style="font-size:20px;background-color:aqua;margin-left:17px;border-radius:5px;"
						href="add.php">Add matches</a>
				</li>


			</ul>


			<a href="admin.php" class="mt-3"><i class="bi bi-person-circle "
					style="font-size:35px;margin-right:17px;"></i></a>

			<?php
       if (isset($_GET['logout'])) {
           cookie::deletecookie();
       }

			?>


			<span class="btn mt-3 bg-primary" style="cursor: pointer;">
				<a href="?logout" style="text-decoration:none;color:white;font-size:20px;">
					logout
				</a></span>





</nav>