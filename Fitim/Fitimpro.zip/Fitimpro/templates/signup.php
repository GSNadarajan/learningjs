
<body class="text-center" style="display:flex;">
<main class="form-signup w-100 m-auto">

  <form action="#" method="post">
    <h1 class="mb-5">Fitimpro</h1>
    
    <div class="form-floating">
      <input type="username" name="name" class="form-control" id="floatingInput" placeholder="username">
      <label for="floatingInput">Username</label>
    </div>
    <div class="form-floating">
      <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Password</label>
    </div>
    <button class="w-100 btn btn-lg btn-primary mt-3" name="submit" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2017–2022</p>
 </form>
</main>