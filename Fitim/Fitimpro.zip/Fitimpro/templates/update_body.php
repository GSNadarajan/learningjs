<div class="container">
	<div class="row">
		<div class="col-4"></div>
		<div class="col-4">
			<?php
            if (isset($_GET['id'])) {
                $id =$_GET['id'];
                if (isset($_POST['title'])) {
                    $title = $_POST['title'];
                    $description = $_POST['desc'];
                    $winner = $_POST['winner'];
                    $team1 = $_POST['team1'];
                    $team2 = $_POST['team2'];
                    $score1 = $_POST['score1'];
                    $score2 = $_POST['score2'];
                    $date = $_POST['date'];

                    $query = "UPDATE matches SET title='$title' , description='$description' ,winner='$winner' , team='$team1,$team2' , score = '$score1,$score2' , date = '$date' , updated_at = now() WHERE id='$id'";
                    Data::updatematch($query);
                }

                $query = "SELECT title,description,score,team,date,winner from matches WHERE id='$id'";
                $values = Data::selectmatch($query);

                $title = $values[0]["title"];
                $description = $values[0]["description"];
                $date = $values[0]["date"];
                $score = explode(",", $values[0]['score']);
                $score1 = $score[0];
                $score2 = $score[1];
                $team = explode(",", $values[0]['team']);
                $team1 = $team[0];
                $team2 = $team[1];
                ?>
				
			<main class="form-signin w-100 m-auto">
				<form action="#" method="post">
					<h1 class="mb-3 text-center">Match Records</h1>
					<div class="form-group">
						<label>Title</label>
						<input type="name" name="title" class="form-control mt-2"
							value="<?= $title ?>" required>
					</div>
					<div class="form-group mt-3">
						<label>Description</label>
						<!-- <input type="text"name="description" class="form-control mt-2"  " required> -->
						<textarea id="w3review" type="text" name="desc" class="form-control mt-2" rows="4" cols="50"
							value=""><?php print_r($values[0]['description'])?></textarea>
					</div>
					<label class="mt-3">Winner</label>


					<?php



                            $winner = $values[0]['winner'];



                //  $winner = 2;
                if ($winner == 0) {
                    $winner = "draw";
                    ?>
					<select class="form-select mt-2 winner" name="winner" aria-label=" example">

						<option value="0">Draw</option>
						<option value="1">Team one</option>
						<option value="2">Team two</option>
					</select>



					<?php

                } elseif ($winner == 1) {
                    $winner = "team one win";
                    ?>
					<select class="form-select mt-2 winner" name="winner" aria-label=" example">


						<option value="1">Team one</option>
						<option value="0">Draw</option>
						<option value="2">Team two</option>
					</select>

					<?php

                } else {
                    $winner = "team two win";
                    ?>
					<select class="form-select mt-2 winner" name="winner" aria-label=" example">
						<option value="2">Team two</option>
						<option value="0">Draw</option>
						<option value="1">Team one</option>
					</select>
					<?php
                }

                ?>


					<div class="row mt-3">
						<label>Team</label>

						<div class="col mt-2">
							<input type="int" name="team1" class="form-control" placeholder="team one score"
								value="<?= $team1 ?>" required>
						</div>

						<div class="col mt-2">

							<!-- <label >Email address</label> -->
							<input type="int" name="team2" class="form-control" placeholder="team two score"
								value="<?= $team2 ?>" required>
						</div>

					</div>

					<div class="row mt-3">
						<label>Scores</label>

						<div class="col mt-2">
							<input type="int" name="score1" class="form-control" placeholder="team one score"
								value="<?= $score1 ?>" required>
						</div>

						<div class="col mt-2">
							<!-- <label >Email address</label> -->
							<input type="int" name="score2" class="form-control" placeholder="team two score"
								value="<?= $score1 ?>" required>
						</div>

					</div>


					<div class="mt-2">
						<div class="col mt-2">
							<label class="mt-2">Match date</label>

							<input type="date" name="date" class="form-control mt-2"
								value="<?= $date ?>" required>
						</div>



					</div>



					<button class=" btn btn-lg btn-primary mt-4 w-100" name="submit" type="submit">Update</button>

				</form>
			</main>
			<?php
            }
			?>
		</div>
		<div class="col-4"></div>
	</div>
</div>


