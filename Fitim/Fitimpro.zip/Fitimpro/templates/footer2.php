<footer class="border-top" style="margin-top:140px;">
   
    <p class="text-center text-muted">© 2022 Company, Inc</p>
  </footer>
 
</div>

    
</body>

</html>
