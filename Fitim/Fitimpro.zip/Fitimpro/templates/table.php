<?php



?>


<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
	<meta name="generator" content="Hugo 0.101.0">
	<title>Admin Dashboard page</title>
	<link href="https://fonts.gstatic.com" rel="preconnect">
	<link
		href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
		rel="stylesheet">
	<link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/dashboard/">
	<!-- <link href="bootstrap.min.css" rel="stylesheet"> -->
	<!-- History CDN -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">


	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
	<link
		href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
		rel="stylesheet">
	<link rel="stylesheet" type="text/css"
		href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script type="text/javascript" language="javascript"
		src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript"
		src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
	<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
	<script type="text/javascript" language="javascript" src="assets/dist/js/bootstrap.bundle.min.js"></script>

  <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">



	<!-- style -->

	<style>
		body {
			font-family: "Poppins", sans-serif;
			padding-right: 170px;
		}

		.btn-success {
			background-color: #17b16a;
			border-color: #17b16a;
		}

		.badge {
			font-weight: 300 !important;
		}
	</style>
</head>


<body class="wide comments example dt-example-bootstrap5">
  <div class="container mt-3">
    <?php 
if (isset($_GET['deleted'])) {
    if ($_GET['deleted'] == "success") {
        ;
    
    ?>
  <div class="alert alert-success " role="alert">
     Successfully deleted
</div>

<?php
}else{
?>
<div class="alert alert-danger " role="alert">
     Error in Database
</div>

<?php
 }
}
      ?>
 <br>
<?php include "nav.php"; ?>
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Are you sure want to delete ?</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
					<input type="hidden" id="current_user" value="">
					<button type="button" onclick="del()" class="btn btn-primary"> Yes </button>
				</div>
			</div>
		</div>
	</div>


	<br>

	<table id="example" class="table table-striped" style="width:100%">
		<thead>
			<tr>
				<th>id</th>
				<th>Title</th>
				<th>Description</th>
				<th>Status</th>
				<th>Team1</th>
				<th>Team2</th>
				<th>score1</th>
				<th>score2</th>
				<th>Match_date</th>
				<th>Update</th>
				<th>Delete</th>

			</tr>
		</thead>
		<tbody>
			<?php
foreach ($values as $key => $info) {
    // print_r($info['team']);
    $team = $info['team'];
    $team =explode(",", $info['team']);
    $team1 = $team[0];
    $team2 =$team[1];
    $score =$info['score'];
    $score = explode(",", $info['score']);
    $score1 = $score[0];
    $score2 = $score[1];

    if ($info['winner'] == 0) {
        $info['winner'] = "Draw";
    }
    if ($info['winner'] == 1) {
        $info['winner'] = "Team one won";
    }
    if ($info['winner'] == 2) {
        $info['winner'] = "Team two won";
    }


    ?>
			<tr>
				<td><?=$key + 1?>
				</td>
				<td><?=$info['title']?>
				</td>
				<td><?=$info['description']?>
				</td>
				<td><?=$info['winner']?>
				</td>
				<td><?=$team1?>
				</td>
				<td><?=$team2?>
				</td>
				<td><?=$score1?>
				</td>
				<td><?=$score2?>
				</td>
				<td><?=$info['date']?>
				</td>
				<td><a
						href="update.php?id=<?php echo $info['id']?>"><button
							type="button" class="btn btn-primary">Update</button></a></td>

				<td><svg style="cursor:pointer"
						onclick="update_delete(<?php echo $info['id']; ?>)"
						data-bs-toggle="modal" data-bs-target="#exampleModal" xmlns="http://www.w3.org/2000/svg"
						width="22" height="22" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
						<path
							d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
						<path fill-rule="evenodd"
							d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
					</svg>
				</td>

			</tr>
			<?php
}

?>

			<?php


?>
		</tbody>

	</table>

	<script type="text/javascript">
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-365466-5']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script');
			ga.type = 'text/javascript';
			ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') +
				'.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0];
			s.parentNode.insertBefore(ga, s);
		})();

		function del() {
			var id = $("#current_user").val();
			$.ajax({
				type: "POST",
				url: "delete.php",
				data: {
					"user": id
				},
				dataType: "json",
				encode: true,
			}).done(function(data) {
				if (data.success == true) {
				 window.location.href="index.php?deleted=success";
				} else if (data.success == false) {
					alert("Error in database");
				}
			});
		}


		function update_delete(id) {
			$("#current_user").val(id);
		}
	</script>


	<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"
		integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous">
	</script>
	<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"
		integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous">
	</script>


	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
	<script src=""></script>

	<!-- User_list status change for admin -->
	<!-- https://datatables.net/reference/api/button().trigger() -->
	<!-- TODO : Export table problem fix -->
	<script>
		$(document).ready(function() {

			var table = $('#example').DataTable({
				dom: 'Bfrtip',
				buttons: [
					'copy', 'csv', 'excel', 'print'
				]
			});

		});
	</script>
  </div>
</body>

</html>