

    <main class="form-signin w-100 m-auto">

<form action="#" method="post">
  <h1 class="mb-3 text-center">Match Records</h1>

         <div class="form-group">
             <label >Title</label>
              <input type="name" name="title" class="form-control mt-2" value=""  required>

            </div>
            <div class="form-group mt-3">
              <label>Description</label>
              <!-- <input type="password"name="des" class="form-control mt-2"  required> -->
              <textarea id="w3review"  type="text"name="desc" class="form-control mt-2"rows="4" cols="50"></textarea>
              
            </div>
  


            <div class="form-row align-items-center mt-3">
              <!-- <label>Winner</label> -->
           
              <label class="" for="inlineFormCustomSelect">Winner</label>
           

                      <select class="form-select mt-2 winner" name="winner" aria-label=" example">
                         <option selected>Select the winner</option>
                        <option value="0">Draw</option>
                        <option value="1">Team one</option>
                       <option value="2">Team two</option>
                      </select>
             </div>


             <div class="row mt-3">
    
 
               <label>Teams</label>

      <div class="col mt-2">
    
      <input type="int" name="team1" class="form-control " placeholder="team one name" required>
      </div>

      <div class="col mt-2">

      <input type="int" name="team2" class="form-control "  placeholder="team two name" required>
      </div>

    </div>
  


    <div class="row mt-3">
    <label >Scores</label>

      <div class="col mt-2">
      <input type="int" name="score1" class="form-control" placeholder="team one score" required>
      </div>

      <div class="col mt-2">
      <input type="int" name="score2" class="form-control" placeholder="team two score" required>
      </div>

    </div>

    <div class="mt-2">
    <div class="col mt-2">
      <label >Match date</label>
    
         
      <input type="date" name="date" class="form-control mt-2"  required>
      </div>

    
      
    </div>

  

      <button class=" btn btn-lg btn-primary mt-4 w-100" name="submit" type="submit">Submit</button>
  


      </div>

          </form>

    </div>





</form>
</main>


    </div>

    <div class="col-4"></div>

  </div>