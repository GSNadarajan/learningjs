<main class="form-signin w-100 m-auto">

<form action="#" method="post">
    <h1 class="mb-3 text-center">Admin login</h1>

    <div class="form-group">
        <label>Username</label>
        <br>
        <input type="name" name="name" class="form-control mt-2" required>
        <!-- <input type="name" name="name" class="form-control"  required> -->


    </div>
    <br>
    <div class="form-group">
        <label>Password</label>
        <input type="password" name="pass" class="form-control mt-2" required>
    </div>
    <br>

    <div class="form-group">
        <label>Email address</label>
        <input type="email" name="email" class="form-control mt-2" required>

    </div>
    <br>



    <div class="form-group">
        <label>Phone</label>
        <br>
        <input type="phone" name="phone" class="form-control mt-2" required>

    </div>

    <button class=" btn btn-lg btn-primary mt-4 w-100" name="submit" type="submit">Update</button>
    <!-- <p class="mt-5 mb-3 text-muted">&copy; 2017–2022</p> -->



</div>

</form>

</div>





</form>
</main>
</div>

<div class="col-4"></div>

</div>
</div>

</div>