<?php

include "libs/cookie/cookies.php";
include "libs/load.php";
cookie::checkcookie(); // to check the cookie
load_template("head"); 
load_template("nav");
?>
<div class="container " style="margin-top:100px;">
    <div class="row ">
		<div class="col-4"></div>
		<div class="col-4">
<?php
if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $email =$_POST['email'];
    $pass = $_POST['pass'];
    $phone = $_POST['phone'];
    $query = "UPDATE login SET username='$name' , password='$pass' , email='$email' , phone = '$phone'  WHERE id=1";
    Data::update($query); 
}

load_template("admin");
load_template("footer1");

?>



			













