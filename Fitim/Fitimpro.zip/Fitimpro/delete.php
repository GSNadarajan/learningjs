<?php
include "libs/load.php";

if(isset($_POST['user']) and is_numeric($_POST['user'])){
    $id = $_POST['user'];
     $sql ="UPDATE `matches` SET `deleted_at` = now()  WHERE `id` = '$id'";
    if(Data::update_del($sql)){
        $data['success'] = true;

    }
    else{
        $data['success'] = false;
    }
echo json_encode($data);

}
