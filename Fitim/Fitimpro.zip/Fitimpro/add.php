<?php
 include "libs/load.php";  //It contains a function which load all the modules
 include "libs/cookie/cookies.php";
 cookie::checkcookie();
 load_template("head");
 load_template("nav");
?>
 <div class="container">
 <div class="row">
    <div class="col-4"></div>
    <div class="col-4">
 <?php
 if (isset($_POST['title'])) {
     $title = $_POST['title'];
     $des =  $_POST['desc'];
     $winner = $_POST['winner'];
     $team1 = $_POST['team1'];
     $team2 = $_POST['team2'];
     $score1 = $_POST['score1'];
     $score2 = $_POST['score2'];
     $date = $_POST['date'];
     $query = "INSERT INTO `matches` (`title`, `description`, `winner`, `team`, `score` ,`date` ,`enabled` , `created_at` )
     VALUES ('$title', '$des', '$winner', '$team1,$team2' , '$score1,$score2' , '$date' , '0' , now())";
     Data::add($query);
    
 }
 load_template("addmatch");
 load_template("footer1");
 ?>




