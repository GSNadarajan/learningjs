<?php

include "libs/load.php";
load_template("head");
if (isset($_POST['name']) and isset($_POST['pass'])) {
    $query = "SELECT username, password FROM login WHERE id=1";
    $values = Data::get($query);
}
Data::check($_POST['name'], $_POST['pass'], $values); // static function to check the user input with db data to check
load_template("signup");

?>




