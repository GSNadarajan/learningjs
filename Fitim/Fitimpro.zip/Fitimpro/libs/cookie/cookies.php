<?php

class cookie
{
    public static function checkcookie()
    {
        if (isset($_COOKIE['admin'])) {
            if ($_COOKIE['admin'] != md5('admin')) {
                header("Location: signup.php");
            }
        } else {
            header("Location: signup.php");
        }
    }

    public static function deletecookie()
    {
    // if (isset($_POST['name'])) {
    //     $cookie_name = $_POST['name'];
    //     $cookie_value = md5($_POST['name']);


        if (isset($_GET['logout'])) {
            setcookie("admin","", time() -3600, "/");
            //  echo "cookie have been deleted";
            header("Location: signup.php");
        }
    }

}

// cookie::checkcookie();
