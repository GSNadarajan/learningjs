<?php
include "db/config.php";
include "db/db.class.php";


// echo __DIR__ . "/templates/$name.php";
function load_template($name)
{
    include "templates/$name.php";
    // echo "function";
}
