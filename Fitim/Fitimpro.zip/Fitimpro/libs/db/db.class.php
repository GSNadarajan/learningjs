<?php

class Data

{

    public static function process($sql)
    {
        $conn = Database::getConnection();
        $result = $conn->query($sql);
        return $result;
    }
    public static function get($sql)  
    {
        $conn = Database::getConnection();
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $values = [];
            while ($row = $result->fetch_assoc()) {
                $values[] = $row;
            }
        }
        return $values;
    }


    public static function check($name,$password,$values){  //To check the values to make signup
        if (isset($name) and isset($password)) {
            if (($name == $values[0]["username"]) and ($password == $values[0]["password"])) {
                header("Location: index.php");
                $cookie_name = "admin";
                $cookie_value = md5($cookie_name);
        
                setcookie($cookie_name, $cookie_value, time() + (3600), "/");
        
            // echo "success";
            } else {
                echo'<div class="alert alert-danger" role="alert">
        Username and Password are incorrect </div>';
            }
        }
        return true;
        
    }

    public static function add($sql){
        
        $conn = Database::getConnection();
        if ($conn->query($sql) === true) {
            echo'<div class="alert alert-success" role="alert">
     Record added succesfully</div>';
        }
        return true;
    }

    public static function update($sql){
         $conn = Database::getConnection();
        if (mysqli_query($conn, $sql)) {
            echo'<div class="alert alert-success" role="alert">
        Record updated succesfully</div>';
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
        return true;

    } 

    public static function updatematch($sql){
          $conn = Database::getConnection();
        if ($conn->query($sql) === true) {
            echo'<div class="alert alert-success" role="alert">
            Record updated succesfully</div>';
           } else {
            //    echo "Error updating record: " . $conn->error;
            echo'<div class="alert alert-danger" role="alert">
            Enter valid records</div>';
           }
    return true;
    }

    public static function selectmatch($sql){
        $conn = Database::getConnection();
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $values = [];
            while ($row = $result->fetch_assoc()) {
                $values[] = $row;
            }
        } 
        return $values;
    }

    public static function update_del($sql){
        $conn = Database::getConnection();   
      if ($conn->query($sql) === true) {
         return true;
      } 
      else
       {
        return false;
       }

           
    }

}
