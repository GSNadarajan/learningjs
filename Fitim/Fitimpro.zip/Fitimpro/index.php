<?php
include "libs/load.php"; //It contains a function which load all the modules
include "libs/cookie/cookies.php";
cookie::checkcookie(); 

$query = "SELECT * from matches WHERE `deleted_at` IS NULL ORDER BY `id` DESC ";
$values = Data::selectmatch($query);
 //To check the cookie will avail in this index.php page
include "templates/table.php";

?>