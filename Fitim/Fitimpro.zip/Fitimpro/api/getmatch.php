<?php
include "../libs/load.php";
if (isset($_GET['match_date']) and $_SERVER['HTTP_API_KEY'] == "5d41402abc4b2a76b9719d911017c592"){
 $match_date = $_GET['match_date'];
 $split = explode("-", $match_date);
 $year = $split[0];
 $month = $split[1];
 $day = $split[2];
 $dob = "$day/$month/$year";
   
 if(preg_match("/^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/", $dob)) {
    $sql= "SELECT * FROM `matches` WHERE `date` LIKE  '%$match_date%' AND `deleted_at` IS NULL";
    $values = Data::selectmatch($sql);
    if($values){
      $data['success'] = true;
      $data['values'] = $values;
    }
    else{
      $data['success'] = false ;
      $data['message'] = "The date not found" ;
    }
  }
  else{
    $data['success'] = false ;
    $data['message'] = "The date isn't in correct format" ;
 }
  echo json_encode($data);
}
else{
    $data['success'] = false ;
    $data['message'] = "Match date or api key not found" ;

echo json_encode($data);
   
}